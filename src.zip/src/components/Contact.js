import React from 'react';
var Contact = () => {

return (
	<>
	<h1 style={{color:"green"}}>
		This is a Contact Page.</h1>
</>
)
};

export default Contact;
