import React from 'react';
var About = () => {

return (
<>
	<h1 style={{color:"green"}}>
		A Computer Science portal for geeks.</h1>
</>
)
};

export default About;
